package com.briup.cms.config;

public class FilterConfig {

}
